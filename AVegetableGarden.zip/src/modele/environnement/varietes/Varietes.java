package modele.environnement.varietes;

public enum Varietes {
    salade, carrotte
}
